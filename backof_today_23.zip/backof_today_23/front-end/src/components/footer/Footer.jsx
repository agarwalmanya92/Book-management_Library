import React from 'react'
// import "./footer.css"
export const Footer = () => {
  return (
    <>
 
 <footer
  style={{
    marginTop: "5%",
    backgroundColor: "black",
    color: "white",
    padding: "40px 0",
  }}
>
  <div className="container">
    <div className="row">
      {/* Column 1: About */}
      <div className="col-md-4 mb-3">
        <h5>About Library</h5>
        <p>
          Our Library Management System helps manage books, track borrowings,
          and provide a digital catalog for students and staff. Trusted by
          institutions for its simplicity and power.
        </p>
      </div>

      {/* Column 2: Quick Links */}
      <div className="col-md-4 mb-3">
        <h5>Quick Links</h5>
        <ul className="list-unstyled">
          <li>
            <a href="#" className="text-white text-decoration-none">
              Home
            </a>
          </li>
          <li>
            <a href="#" className="text-white text-decoration-none">
              Catalog
            </a>
          </li>
          <li>
            <a href="#" className="text-white text-decoration-none">
              My Account
            </a>
          </li>
          <li>
            <a href="#" className="text-white text-decoration-none">
              Contact
            </a>
          </li>
        </ul>
      </div>

      {/* Column 3: Contact Info */}
      <div className="col-md-4 mb-3">
        <h5>Contact Us</h5>
        <p>
          <strong>Email:</strong> support@library.com <br />
          <strong>Phone:</strong> +91 9876543210 <br />
          <strong>Address:</strong> BBD Campus, Lucknow, UP
        </p>
      </div>
    </div>
    <hr className="text-white" />
    <div className="text-center mt-3">
      <p className="mb-0">&copy; 2025 Library Management. All rights reserved.</p>
    </div>
  </div>
</footer>

</>

  )
}
